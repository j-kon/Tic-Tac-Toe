package com.example.jaykon.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

  Button bt;

  @Override
    protected void onCreate(Bundle savedInstantState){
      super.onCreate(savedInstantState);
      setContentView(R.layout.activity_main);

      bt = findViewById(R.id.button3);
      bt.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent myIntent = new Intent(MainActivity.this, start.class);
              startActivities(new Intent[]{myIntent});

       bt = findViewById(R.id.button5);
       bt.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent myIntent = new Intent(MainActivity.this, start2.class);
               startActivities(new Intent[]{myIntent});


           }
       });
          }
      });

  }

}



